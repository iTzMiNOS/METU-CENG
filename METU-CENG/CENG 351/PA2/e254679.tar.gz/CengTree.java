import java.util.ArrayList;

public class CengTree
{
    public CengTreeNode root;
    // Any extra attributes...

    public CengTree(Integer order)
    {
        CengTreeNode.order = order;
        // TODO: Initialize the class
        this.root = new CengTreeNodeLeaf(null);

    }

    public void addBook(CengBook book)
    {
        // TODO: Insert Book to Tree
        this.root.addBook(book, this);
    }

    public ArrayList<CengTreeNode> searchBook(Integer bookID)
    {
        // TODO: Search within whole Tree, return visited nodes.
        // Return null if not found.
        CengTreeNode Root = this.root;
        CengBook temp_book = null;
        ArrayList<CengTreeNode> TTree = new ArrayList<>();

        while (Root != null) {
            TTree.add(Root);
            if (Root.type == CengNodeType.Leaf) {
                CengTreeNodeLeaf nodeLeaf = (CengTreeNodeLeaf) Root;
                temp_book = nodeLeaf.search(bookID);
                break;
            }else if (Root.type == CengNodeType.Internal)
            {
                CengTreeNodeInternal nodeInternal = (CengTreeNodeInternal) Root;
                Root = nodeInternal.search(bookID);
            }
        }
        int TTsize = TTree.size();
        if (temp_book == null) {
            System.out.print("Could not find " + bookID);
            return null;
        }else{
            int i = 0;
            while (i < TTsize) {
                CengTreeNode currentNode = TTree.get(i);

                if (currentNode.type == CengNodeType.Leaf) {
                    CengTreeNodeLeaf nodeLeaf = (CengTreeNodeLeaf) currentNode;
                    nodeLeaf.printBook(temp_book, i);
                } else if (currentNode.type == CengNodeType.Internal) {
                    CengTreeNodeInternal nodeInternal = (CengTreeNodeInternal) currentNode;
                    nodeInternal.printWC(i);
                }

                i++;
            }
            return TTree;
        }
    }
    public void printTree()
    {
        // TODO: Print the whole tree to console
        if (this.root != null) {
            this.root.print(0);
        }
    }
    // Any extra functions...
}
