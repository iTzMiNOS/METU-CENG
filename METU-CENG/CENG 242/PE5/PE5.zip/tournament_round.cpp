#include "tournament_round.h"

// TournamentRound functions goes here

TournamentRound::TournamentRound() {}

TournamentRound::TournamentRound(std::list<MusicBand*> _bands)
    : bands(std::move(_bands)) {}

TournamentRound::TournamentRound(std::vector<MusicBand*> _bands)
{
    bands.insert(bands.end(), _bands.begin(), _bands.end());
}

std::size_t TournamentRound::size()
{
    return bands.size();
}


TournamentRound& TournamentRound::operator=(TournamentRound&& other)
{
    if (this != &other) {
        bands = std::move(other.bands);
    }
    return *this;
}

TournamentRound& TournamentRound::get_next_round()
{
    std::list<MusicBand*> winners;
    auto it = bands.begin();
    auto lastBandIt = bands.end();
    lastBandIt--;
    int fchange;
    while (it != bands.end()) {
        if(it == lastBandIt){
            winners.push_back(*it);
            break;
        }
        if(it == std::next(lastBandIt)){
            break;
        }
        MusicBand* band1 = *it;
        MusicBand* band2 = *lastBandIt;
        int result1 = band1->play(band2);
        int result2 = band2->play(band1);
        if(band1->get_energy() < 0){
            result1  = result2 - 1;
        }
        if(band2->get_energy() < 0){
            result2  = result1 - 1;
        }
        if (result1 >= result2) {
            fchange = result1 - result2;
            winners.push_back(band1);
            fchange = fchange > band2->get_fan_count() ? band2->get_fan_count() : fchange;
            band1->set_fan_count(band1->get_fan_count() + fchange);
            if(band2->get_fan_count() - fchange < 0){
                band2->set_fan_count(0);
            }else{
                band2->set_fan_count(band2->get_fan_count() - fchange);
            }
        }
        else {
            fchange = (result1 - result2) * (-1);
            winners.push_back(band2);
            fchange = fchange > band1->get_fan_count() ? band1->get_fan_count() : fchange;
            band2->set_fan_count(band2->get_fan_count() + fchange);
            if(band1->get_fan_count() - fchange < 0){
                band1->set_fan_count(0);
            }else{
                band1->set_fan_count(band1->get_fan_count() - fchange);
            }
        }
        it = std::next(it);
        lastBandIt = std::prev(lastBandIt);
    }
    bands.clear();
    bands = std::move(winners);
    return *this;
}

std::ostream& operator<<(std::ostream& os, TournamentRound& other)
{
    for (const auto& band : other.bands) {
        os << band->get_name();
        if (&band != &other.bands.back()) {
            os << '\t';
        }
    }
    return os;
}

