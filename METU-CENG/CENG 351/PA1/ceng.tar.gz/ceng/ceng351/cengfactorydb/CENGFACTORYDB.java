package ceng.ceng351.cengfactorydb;

import java.sql.*;
import java.util.*;

public class CENGFACTORYDB implements ICENGFACTORYDB{
    /**
     * Place your initialization code inside if required.
     *
     * <p>
     * This function will be called before all other operations. If your implementation
     * need initialization , necessary operations should be done inside this function. For
     * example, you can set your connection to the database server inside this function.
     */
    private static Connection conn = null;
    public void initialize() {

            String url = "jdbc:mysql://" + "144.122.71.128" + ":" + "8080" + "/" + "db2546794";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                this.conn =  DriverManager.getConnection(url, "e2546794", "m^ZC^T0vL#MF");
            }
            catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
    }

    /**
     * Should create the necessary tables when called.
     *
     * @return the number of tables that are created successfully.
     */
    public int createTables() {
        int num_of_tables = 0;
        String Create = "CREATE TABLE IF NOT EXISTS";
        String FactoryINIT = Create + " Factory(" +
                "factoryId INT," +
                "factoryName VARCHAR(30)," +
                "factoryType VARCHAR(30)," +
                "country VARCHAR(30)," +
                "PRIMARY KEY (factoryId)" +
                ");";

        String EmployeeINIT = Create + " Employee(" +
                "employeeId INT NOT NULL, " +
                "employeeName VARCHAR(30), " +
                "department VARCHAR(20), " +
                "salary INT, " +
                "PRIMARY KEY (employeeId));";

        String Works_InINIT = Create + " Works_In(" +
                "factoryId INT NOT NULL, " +
                "employeeId INT NOT NULL, " +
                "startDate DATE, " +
                "FOREIGN KEY (factoryId) REFERENCES Factory ON DELETE CASCADE, " +
                "FOREIGN KEY (employeeId) REFERENCES Employee ON DELETE CASCADE, " +
                "PRIMARY KEY (factoryId, employeeId));";

        String ProductINIT = Create + " Product(" +
                "productId INT NOT NULL, " +
                "productName VARCHAR(30), " +
                "productType VARCHAR(20), " +
                "PRIMARY KEY (productId));";

        String ProduceINIT = Create + " Produce(" +
                "factoryId INT NOT NULL, " +
                "productId INT NOT NULL, " +
                "amount INT, " +
                "productionCost INT, " +
                "FOREIGN KEY (factoryId) REFERENCES Factory ON DELETE CASCADE, " +
                "FOREIGN KEY (productId) REFERENCES Product ON DELETE CASCADE, " +
                "PRIMARY KEY (factoryId, productId));";

        String ShipmentINIT = Create + " Shipment(" +
                "factoryId INT NOT NULL, " +
                "productId INT NOT NULL, " +
                "amount INT, " +
                "pricePerUnit INT, " +
                "FOREIGN KEY (factoryId) REFERENCES Factory(factoryId), " +
                "FOREIGN KEY (productId) REFERENCES Product(productId), " +
                "PRIMARY KEY (factoryId, productId));";

        int result;

        try{
            conn.prepareStatement(FactoryINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        try{
            conn.prepareStatement(EmployeeINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        try{
            conn.prepareStatement(Works_InINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        try{
            conn.prepareStatement(ProductINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        try{
            conn.prepareStatement(ProduceINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        try{
            conn.prepareStatement(ShipmentINIT).execute();
            num_of_tables += 1;
        } catch (SQLException e){
            e.printStackTrace();
        }

        return num_of_tables;
    }

    /**
     * Should drop the tables if exists when called.
     *
     * @return the number of tables are dropped successfully.
     */
    public int dropTables() {
        int num_of_dropped = 0;
        int result;
        String[] tables = {"Works_In", "Produce", "Shipment", "Factory", "Employee", "Product"};
        String drop_table = "DROP TABLE IF EXISTS ";

        for (int i = 0; i < 6; i++){
            try{
                conn.prepareStatement("DROP TABLE IF EXISTS " + tables[i]).execute();
                num_of_dropped += 1;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }
        return num_of_dropped;
    }

    /**
     * Should insert an array of Factory into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertFactory(Factory[] factories) {
        int num_of_inserted = 0;
        for (Factory factory: factories){
            try{
            String sql = "INSERT INTO Factory VALUES (" +
                    factory.getFactoryId() + ",'" +
                    factory.getFactoryName() + "','" +
                    factory.getFactoryType() + "','" +
                    factory.getCountry() + "');";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }

    /**
     * Should insert an array of Employee into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertEmployee(Employee[] employees) {
        int num_of_inserted = 0;
        for (Employee employee: employees){
            try{
            String sql = "INSERT INTO Employee VALUES (" +
                    employee.getEmployeeId() + ",'" +
                    employee.getEmployeeName() + "','" +
                    employee.getDepartment() + "'," +
                    employee.getSalary() + ");";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }

    /**
     * Should insert an array of WorksIn into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertWorksIn(WorksIn[] worksIns) {
        int num_of_inserted = 0;
        int l = worksIns.length;
        int result;
        for (WorksIn worksIn: worksIns){
            try{
            String sql = "INSERT INTO Works_In VALUES (" +
                    worksIn.getFactoryId() + ", " +
                    worksIn.getEmployeeId() + ",'" +
                    worksIn.getStartDate() + "');";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }

    /**
     * Should insert an array of Product into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertProduct(Product[] products) {
        int num_of_inserted = 0;
        for (Product product: products){
            try{
                String sql = "INSERT INTO Product VALUES (" +
                    product.getProductId() + ",'" +
                    product.getProductName() + "','" +
                    product.getProductType() + "');";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }


    /**
     * Should insert an array of Produce into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertProduce(Produce[] produces) {
        int num_of_inserted = 0;
        for (Produce produce: produces){
            try{
            String sql = "INSERT INTO Produce VALUES (" +
                    produce.getFactoryId() + "," +
                    produce.getProductId() + "," +
                    produce.getAmount() + "," +
                    produce.getProductionCost() + ");";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }


    /**
     * Should insert an array of Shipment into the database.
     *
     * @return Number of rows inserted successfully.
     */
    public int insertShipment(Shipment[] shipments) {
        int num_of_inserted = 0;
        for (Shipment shipment: shipments){
            try{
            String sql = "INSERT INTO Shipment VALUES (" +
                    shipment.getFactoryId() + "," +
                    shipment.getProductId() + "," +
                    shipment.getAmount() + "," +
                    shipment.getPricePerUnit() + ");";

                conn.prepareStatement(sql).execute();
                num_of_inserted++;
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }

        return num_of_inserted;
    }

    /**
     * Should return all factories that are located in a particular country.
     *
     * @return Factory[]
     */
    public Factory[] getFactoriesForGivenCountry(String country) {

        String Select = "SELECT DISTINCT * " + "FROM Factory fac ";
        String Condition = "WHERE fac.country = '" + country + "' " + "ORDER BY fac.factoryId ASC;";
        try {
            ResultSet temp = (conn.prepareStatement(Select + Condition)).executeQuery();
            ArrayList<Factory> res = new ArrayList<Factory>();
            while (temp.next()){
                res.add(new Factory(
                        temp.getInt("factoryId"),
                        temp.getString("factoryName"),
                        temp.getString("factoryType"),
                        temp.getString("country")
                ));
            };
            return res.toArray(new Factory[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Factory[0];
    }



    /**
     * Should return all factories without any working employees.
     *
     * @return Factory[]
     */
    public Factory[] getFactoriesWithoutAnyEmployee() {

        String Select = "SELECT DISTINCT * " + "FROM Factory fac ";
        String Condition = "WHERE fac.factoryId NOT IN (SELECT DISTINCT tempfac.factoryId " + "FROM Factory tempfac, Works_In tempWI " +
                "WHERE tempWI.factoryId = tempfac.factoryId) " + "ORDER BY fac.factoryId ASC;";
        try {
            ResultSet temp = (conn.prepareStatement(Select + Condition)).executeQuery();
            ArrayList<Factory> res = new ArrayList<Factory>();

            while (temp.next()){
                res.add(new Factory(
                        temp.getInt("factoryId"),
                        temp.getString("factoryName"),
                        temp.getString("factoryType"),
                        temp.getString("country")
                ));
            };
            return res.toArray(new Factory[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Factory[0];
    }

    /**
     * Should return all factories that produce all products for a particular productType
     *
     * @return Factory[]
     */
    public Factory[] getFactoriesProducingAllForGivenType(String productType) {
        String Select = "SELECT DISTINCT * " + "FROM Factory fac ";
        String Condition = "WHERE NOT EXISTS (SELECT productId " + "FROM Product prot " +
                "WHERE prot.productType = '" + productType + "' " + "EXCEPT " + "SELECT prod.productId " +
                "FROM Produce prod " + "WHERE fac.factoryId = prod.factoryId) " + "ORDER BY fac.factoryId ASC;";
        try{
            ResultSet temp = (conn.prepareStatement(Select + Condition)).executeQuery();
            ArrayList<Factory> res = new ArrayList<Factory>();
            while(temp.next()){
                res.add(new Factory(
                        temp.getInt("factoryId"),
                        temp.getString("factoryName"),
                        temp.getString("factoryType"),
                        temp.getString("country")
                ));
            };
            return res.toArray(new Factory[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Factory[0];
    }


    /**
     * Should return the products that are produced in a particular factory but
     * don’t have any shipment from that factory.
     *
     * @return Product[]
     */
    public Product[] getProductsProducedNotShipped() {
        String Select = "SELECT DISTINCT * " + "FROM Product prot ";
        String Condition = "WHERE EXISTS " + "(SELECT DISTINCT prod.factoryId " +  "FROM Produce prod " +
                "WHERE prot.productId = prod.productId " +  "EXCEPT " +  "SELECT DISTINCT ship.factoryId " +
                "FROM Shipment ship " +  "WHERE prot.productId = ship.productId) " +  "ORDER BY prot.productId ASC;";
        try{
            ResultSet temp = (conn.prepareStatement(Select + Condition)).executeQuery();
            ArrayList<Product> res = new ArrayList<Product>();
            while(temp.next()){
                res.add(new Product(
                        temp.getInt("productId"),
                        temp.getString("productName"),
                        temp.getString("productType")
                ));
            };
            return res.toArray(new Product[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Product[0];
    }


    /**
     * For a given factoryId and department, should return the average salary of
     *     the employees working in that factory and that specific department.
     *
     * @return double
     */
    public double getAverageSalaryForFactoryDepartment(int factoryId, String department) {

        String Select = "SELECT AVG(Emp.salary) AS avg FROM Employee Emp, Works_In WIN ";
        String Condition = "WHERE Emp.department = '" + department + "' AND Emp.employeeId = WIN.employeeId AND WIN.factoryId = " + factoryId;
        double avg = 0;
        try {
            ResultSet temp = (conn.prepareStatement(Select + Condition)).executeQuery();
            if (temp.next())
                avg = temp.getDouble("avg");
            return avg;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


    /**
     * Should return the most profitable products for each factory
     *
     * @return QueryResult.MostValueableProduct[]
     */
    public QueryResult.MostValueableProduct[] getMostValueableProducts() {

        String ProfitableProducts = "WITH ProfitableProducts AS (" +
                "SELECT DISTINCT pr.factoryId, pr.productId, p.productName, p.productType, " +
                "((COALESCE(s.amount, 0) * COALESCE(s.pricePerUnit, 0)) - (pr.amount * pr.productionCost)) AS profit " +
                "FROM Product p " +
                "JOIN Produce pr ON p.productId = pr.productId " +
                "LEFT JOIN Shipment s ON pr.factoryId = s.factoryId AND pr.productId = s.productId),";
        String MaxProfit = "MaxProfit AS (" +
                "SELECT pr.factoryId, MAX((COALESCE(s.amount, 0) * COALESCE(s.pricePerUnit, 0)) - (pr.amount * pr.productionCost)) AS maxProfit " +
                "FROM Produce pr " +
                "LEFT JOIN Shipment s ON pr.factoryId = s.factoryId AND pr.productId = s.productId " +
                "GROUP BY pr.factoryId)";
        String OP = "SELECT pp.factoryId, pp.productId, pp.productName, pp.productType, pp.profit " +
                "FROM ProfitableProducts pp " +
                "JOIN MaxProfit mp ON pp.factoryId = mp.factoryId WHERE pp.profit >= mp.maxProfit " +
                "ORDER BY pp.profit DESC, pp.factoryId ASC;";

        try{
            ResultSet temp = (conn.prepareStatement(ProfitableProducts + MaxProfit + OP)).executeQuery();
            ArrayList<QueryResult.MostValueableProduct> res = new ArrayList<QueryResult.MostValueableProduct>();
            while (temp.next())
                res.add(new QueryResult.MostValueableProduct(
                        temp.getInt("factoryId"),
                        temp.getInt("productId"),
                        temp.getString("productName"),
                        temp.getString("productType"),
                        temp.getDouble("profit")
                ));

            return res.toArray(new QueryResult.MostValueableProduct[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new QueryResult.MostValueableProduct[0];
    }

    /**
     * For each product, return the factories that gather the highest profit
     * for that product
     *
     * @return QueryResult.MostValueableProduct[]
     */
    public QueryResult.MostValueableProduct[] getMostValueableProductsOnFactory() {
        String ProfitableProducts = "WITH ProfitableProducts AS (" +
                " SELECT DISTINCT Prod.factoryId, Prod.productId, Prot.productName, Prot.productType, " +
                " ((COALESCE(Ship.amount, 0) * COALESCE(Ship.pricePerUnit, 0)) - (Prod.amount * Prod.productionCost)) AS profit " +
                " FROM Product Prot " +
                " JOIN Produce Prod ON Prot.productId = Prod.productId " +
                " LEFT JOIN Shipment Ship ON Prod.factoryId = Ship.factoryId AND Prod.productId = Ship.productId" +
                ")";
        String OP = "SELECT pp.factoryId, pp.productId, pp.productName, pp.productType, pp.profit " +
                "FROM ProfitableProducts pp " +
                "WHERE pp.profit >= (SELECT MAX((COALESCE(ShipT.amount, 0) * COALESCE(ShipT.pricePerUnit, 0)) - (ProdT.amount * ProdT.productionCost)) " +
                "FROM Produce ProdT " +
                "LEFT JOIN Shipment ShipT ON ProdT.factoryId = ShipT.factoryId AND ProdT.productId = ShipT.productId " +
                "WHERE ProdT.productId = pp.productId ) " +
                "ORDER BY pp.profit DESC, pp.factoryId ASC;";

        try{
            ResultSet temp = (conn.prepareStatement(ProfitableProducts + OP)).executeQuery();
            ArrayList<QueryResult.MostValueableProduct> res = new ArrayList<QueryResult.MostValueableProduct>();
            while (temp.next())
                res.add(new QueryResult.MostValueableProduct(
                        temp.getInt("factoryId"),
                        temp.getInt("productId"),
                        temp.getString("productName"),
                        temp.getString("productType"),
                        temp.getDouble("profit")
                ));

            return res.toArray(new QueryResult.MostValueableProduct[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new QueryResult.MostValueableProduct[0];
    }


    /**
     * For each department, should return all employees that are paid under the
     *     average salary for that department. You consider the employees
     *     that do not work earning ”0”.
     *
     * @return QueryResult.LowSalaryEmployees[]
     */
    public QueryResult.LowSalaryEmployees[] getLowSalaryEmployeesForDepartments() {
        String EMP1 = "(SELECT DISTINCT * " +
                "FROM Employee EMP " +
                "WHERE EMP.employeeId IN (SELECT WIN.employeeId " +
                "FROM Works_In WIN) " +
                "AND EMP.salary < ((SELECT SUM(ALL salary) " +
                "FROM Employee EMPT " +
                "WHERE EMP.department = EMPT.department AND EMPT.employeeId IN (SELECT WINT.employeeId " +
                "FROM Works_In WINT)) / (SELECT COUNT(*) " +
                "FROM Employee EMPT " +
                "WHERE EMP.department = EMPT.department))) ";
        String EMP2 = "(SELECT DISTINCT EMP.employeeId, EMP.employeeName, EMP.department, 0 AS salary " +
                "FROM Employee EMP " +
                "WHERE EMP.employeeId NOT IN (SELECT WIN.employeeId " +
                "FROM Works_In WIN) AND 0 < ( (SELECT SUM(ALL salary) " +
                "FROM Employee EMPT " +
                "WHERE EMP.department = EMPT.department AND EMPT.employeeId IN (SELECT WINT.employeeId " +
                "FROM Works_In WINT)) / (SELECT COUNT(*) " +
                "FROM Employee EMPT " +
                "WHERE EMP.department = EMPT.department))) " +
                "ORDER BY employeeId ASC;";
        try {
            ResultSet temp = (conn.prepareStatement(EMP1 + "UNION " + EMP2)).executeQuery();
            ArrayList<QueryResult.LowSalaryEmployees> res = new ArrayList<QueryResult.LowSalaryEmployees>();
            while (temp.next()) {
                res.add(new QueryResult.LowSalaryEmployees(
                        temp.getInt("employeeId"),
                        temp.getString("employeeName"),
                        temp.getString("department"),
                        temp.getInt("salary")
                ));
            };
            return res.toArray(new QueryResult.LowSalaryEmployees[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new QueryResult.LowSalaryEmployees[0];
    }


    /**
     * For the products of given productType, increase the productionCost of every unit by a given percentage.
     *
     * @return number of rows affected
     */
    public int increaseCost(String productType, double percentage) {

        String STMNT = "UPDATE Produce Prod " +
                "SET productionCost = (productionCost * " + percentage + "/100) + productionCost " +
                "WHERE Prod.productId IN (Select Prot.productId " +
                "FROM Product Prot " +
                "WHERE Prod.productId = Prot.productId AND Prot.productType = '" + productType + "');";
        try {
            return conn.prepareStatement(STMNT).executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


    /**
     * Deleting all employees that have not worked since the given date.
     *
     * @return number of rows affected
     */
    public int deleteNotWorkingEmployees(String givenDate) {

        String STMNT = "DELETE FROM Employee " +
                "WHERE employeeId NOT IN ( " +
                "SELECT DISTINCT WIN.employeeId " +
                "FROM Works_In WIN " +
                "WHERE WIN.startDate >= '" + givenDate + "');";
        try {
            return conn.prepareStatement(STMNT).executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


    /**
     * *****************************************************
     * *****************************************************
     * *****************************************************
     * *****************************************************
     *  THE METHODS AFTER THIS LINE WILL NOT BE GRADED.
     *  YOU DON'T HAVE TO SOLVE THEM, LEAVE THEM AS IS IF YOU WANT.
     *  IF YOU HAVE ANY QUESTIONS, REACH ME VIA EMAIL.
     * *****************************************************
     * *****************************************************
     * *****************************************************
     * *****************************************************
     */

    /**
     * For each department, find the rank of the employees in terms of
     * salary. Peers are considered tied and receive the same rank. After
     * that, there should be a gap.
     *
     * @return QueryResult.EmployeeRank[]
     */
    public QueryResult.EmployeeRank[] calculateRank() {
        return new QueryResult.EmployeeRank[0];
    }

    /**
     * For each department, find the rank of the employees in terms of
     * salary. Everything is the same but after ties, there should be no
     * gap.
     *
     * @return QueryResult.EmployeeRank[]
     */
    public QueryResult.EmployeeRank[] calculateRank2() {
        return new QueryResult.EmployeeRank[0];
    }

    /**
     * For each factory, calculate the most profitable 4th product.
     *
     * @return QueryResult.FactoryProfit
     */
    public QueryResult.FactoryProfit calculateFourth() {
        return new QueryResult.FactoryProfit(0,0,0);
    }

    /**
     * Determine the salary variance between an employee and another
     * one who began working immediately after the first employee (by
     * startDate), for all employees.
     *
     * @return QueryResult.SalaryVariant[]
     */
    public QueryResult.SalaryVariant[] calculateVariance() {
        return new QueryResult.SalaryVariant[0];
    }

    /**
     * Create a method that is called once and whenever a Product starts
     * losing money, deletes it from Produce table
     *
     * @return void
     */
    public void deleteLosing() {

    }
}
