module PE1 where

import Text.Printf

-- PE1: Recipe Calculator
-- The premise of this homework if to write a recipe calculator that
-- calculates: how much a recipe costs to make, what can be made with the
-- ingredients already available, and how much extra ingredients need to
-- be bought in order to make a recipe.

-- Recipe = Recipe Name [(Ingredient, Quantity)]
data Recipe = Recipe String [(String, Double)] deriving Show

-- Price = Price Ingredient Quantity Price
data Price = Price String Double Double deriving Show

-- You can use this as-is
getRounded :: Double -> Double 
getRounded x = read s :: Double
               where s = printf "%.2f" x

sameN :: String -> Price -> Bool
sameN name (Price n _ _) = n == name

-- Calculate how much the given amount of the given ingredient costs
getIngredientCost :: (String, Double) -> [Price] -> Double
getIngredientCost (ingredientName, quantity) prices =
  let (Price _ qtyPerPrice pricePerQty) = head (filter (sameN ingredientName) prices)
  in getRounded((quantity / qtyPerPrice) * pricePerQty)


-- Calculate how much it costs to buy all the ingredients of a recipe
recipeCost :: Recipe -> [Price] -> Double
recipeCost (Recipe _ ingredients) prices = 
    let cost = [getIngredientCost ing prices | ing <- ingredients]
    in sum cost


-- Given a list of how much you already have of each ingredient,
-- calculate how much of which ingredients are missing for a recipe
missingIngredients :: Recipe -> [(String, Double)] -> [(String, Double)]
missingIngredients (Recipe _ ingredients) pantry =
    let x = ingredients
        int = [ (s, dbl2 - dbl1) | (s, dbl1) <- pantry, Just dbl2 <- [lookup s x], dbl1 /= dbl2 , dbl2 - dbl1 > 0]
        dif = [ (s, dbl2) | (s, dbl2) <- x, s `notElem` map fst pantry ]
    in int ++ dif
    --in [(a,b) | (a,b) <- x] ++ [(c,d) | (c,d) <- pantry]


makeu :: [(String, Double)] -> [(String, Double)]
makeu [] = []
makeu (x:xs) = x : makeu (filter (\y -> fst y /= fst x) xs)


-- Given a list of ingredients in your kitchen, calculate what you would
-- have left after making the given recipe. If there isn't enough of an
-- ingredient, the recipe cannot be made! You shouldn't change the amount
-- of ingredient in that case.
makeRecipe :: [(String, Double)] -> Recipe -> [(String, Double)]
makeRecipe pantry (Recipe name ingredients) = 
    let t = (Recipe name ingredients)
    in if missingIngredients t pantry == [] 
        then let p = [(c,d - b) | (a,b) <- ingredients, (c,d) <- pantry,a == c] ++ [(c,d) | (a,b) <- ingredients, (c,d) <- pantry,a /= c]
             in makeu p
        else let p = pantry
             in p
             
             
checkv :: a -> Maybe a -> a
checkv dv mv =
  case mv of
    Just x -> x
    Nothing -> dv


-- Given a list of ingredients you already have, and a list of recipes,
-- make a shopping list showing how much of each ingredient you need
-- to buy, and its cost. Each ingredient mush appear in the shopping list
-- at most once (no duplicates!).
-- Calculate the total cost of all the ingredients needed for a list of recipes
makeShoppingList :: [(String, Double)] -> [Recipe] -> [Price] -> [(String, Double, Double)]
makeShoppingList pantry recipes prices =
  let allr = concatMap (\(Recipe _ ing) -> ing) recipes
      recipe = map (\(n, q) -> (n, sum [q' | (n', q') <- allr, n' == n])) allr
      missing = makeu [(n, q - pq) | (n, q) <- recipe, let pq = checkv 0 (lookup n pantry), q > pq]
      result = [(n, q, getIngredientCost (n, q) prices) | (n, q) <- missing]
  in result
    
    
    
    
    
    
