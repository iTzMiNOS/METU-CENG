#include "type.h"
#include "nullary.h"

namespace sym 
{
	double Const::get_value() const { return value_; }
	Const::operator double() const { double k = value_; return k; }
    
	bool Const::is_con() const {
	    return true;
	}
    
	__expr_t* Const::eval(const var_map_t& var_map) const {return new Const(value_); }

	__expr_t* Const::diff(const std::string& v) const {return new Const(0.0); }

	std::ostream& Const::operator<< (std::ostream &out) const {
	    out << value_;
        return out;
	}

	bool Const::operator==(const __expr_t& other) const {
	    if (const Const* k = dynamic_cast<const Const*>(&other)) {
            return value_ == k->value_;
        } return false;
    }
}

namespace sym 
{
	std::string Var::get_variable() const {return  var_; }
	Var::operator std::string () const {std::string k =  var_; return k; }
	
	bool Var::is_var() const {
	    return true;
	}

	__expr_t* Var::eval(const var_map_t& vars) const {
	    auto it = vars.find(var_);
        if (it != vars.end()) {
            return new Const(it->second);
        }else {
            return new Var(var_);
        }
	}

	__expr_t* Var::diff(const std::string& v) const {
	    if (var_ == v) {
            return new Const(1.0);
        } else {
            return new Const(0.0);
        }
	}
	
	std::ostream& Var::operator<< (std::ostream &out) const {
	    out << var_;
        return out;
	}

	bool Var::operator==(const __expr_t& other) const {
        if (const Var* k = dynamic_cast<const Var*>(&other)) {
            return var_ == k->var_;
        }return false;
    }
}
