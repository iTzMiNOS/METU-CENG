:- module(main, [is_vote_wasted/2, is_candidate_elected/2, candidate_count_from_city/3, all_parties/1, all_candidates_from_party/2, all_elected_from_party/2, election_rate/2, council_percentage/2, alternative_debate_setups/2]).
:- [kb].

is_vote_wasted(City, PoliticalParty) :-
    \+ elected(City, PoliticalParty, _).

is_candidate_elected(Name, PoliticalParty) :-
    candidate(Name, PoliticalParty, City, Temp),
    elected(City, PoliticalParty, ElectedRepresentativeCount),
    Temp =< ElectedRepresentativeCount.

candidate_count_from_city([], _, 0).
candidate_count_from_city([H|T], City, Count) :-
    candidate(H, _, City, _),
    candidate_count_from_city(T, City, SubCount),
    Count is SubCount + 1.
candidate_count_from_city([H|T], City, Count) :-
    \+ candidate(H, _, City, _),
    candidate_count_from_city(T, City, Count).
    
all_parties(ListOfPoliticalParties) :-
    findall(Party, party(Party, _), ListOfPoliticalParties).

all_candidates_from_party(PoliticalParty, ListOfCandidates) :-
    findall(Candidate, candidate(Candidate, PoliticalParty, _, _), ListOfCandidates).
    
all_elected_from_party(PoliticalParty, ListOfCandidates) :-
    findall(Name, is_candidate_elected(Name, PoliticalParty), ListOfCandidates).
    
election_rate(PoliticalParty, Percentage) :-
    findall(Candidate, candidate(Candidate, PoliticalParty, _, _), AllCandidates),
    length(AllCandidates, TotalCandidates),
    (   TotalCandidates = 0
    ->  Percentage = 0
    ;   findall(ElectedCandidate, (elected(_, PoliticalParty, ElectedCount), between(1, ElectedCount, I), nth1(I, AllCandidates, ElectedCandidate)), ElectedCandidates),
        length(ElectedCandidates, ElectedCount),
        Percentage is ElectedCount / TotalCandidates
    ).
    
sumcp([], 0).
sumcp([X | XS], S) :-
    sumcp(XS, NS),
    S is NS + X.

council_percentage(PoliticalParty, Percentage) :-
    findall(ElectedCount, elected(_, PoliticalParty, ElectedCount), ElectedCounts),
    to_elect(ToElectCount),
    sumcp(ElectedCounts, TotalElectedCount),
    Percentage is TotalElectedCount / ToElectCount.

    
