#include "kpop.h"
#include "tournament.h"
#include "tournament_round.h"


int main()
{
    KPopBand band1("eski bir grup", 100, 10, 1000);
    return 0;
}