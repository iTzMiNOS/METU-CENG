{-# LANGUAGE FlexibleInstances #-}

module PE3 where

import Data.List (sort, sortBy)
import Text.Printf (printf)

data Term = Const Integer | Pw Integer Power | Trig Integer Power Trigonometric | Exp Integer Power Exponential

data Power = Power Integer
data Polynomial = Polynomial [(Integer, Power)]
data Exponential = Exponential Polynomial
data Trigonometric = Sin Polynomial | Cos Polynomial

class Evaluable a where
    function :: a -> (Integer -> Double)

class Differentiable a where
    derivative :: a -> [Term]

-- You can use this as is
getRounded :: Double -> Double 
getRounded x = read s :: Double
               where s = printf "%.2f" x

-- You don't have to follow the order the functions appear in the file
-- For example, you could first define all Show instances, then all Eq instances etc.
-- if that implementation order is more convenient for you.

e :: Double
e = 1 + sum [1 / fromIntegral (factorial n) | n <- [1..100]]

factorial :: Integer -> Integer
factorial n = product [1..n]

-- INSTANCES FOR POWER

instance Show Power where
    show (Power 0) = ""
    show (Power 1) = "x"
    show (Power n) = "x^" ++ show n

instance Eq Power where
    (Power n1) == (Power n2) = n1 == n2

instance Ord Power where
    (Power n1) <= (Power n2) = n1 <= n2

instance Evaluable Power where
    function (Power n) x = getRounded $ (fromInteger x) ** (fromInteger n)


instance Differentiable Power where
    derivative (Power 0) = []
    derivative (Power n) = [Pw n (Power (n - 1))]



-- INSTANCES FOR POLYNOMIAL
pD :: Polynomial -> [(Integer, Power)]
pD (Polynomial p) = p

showC :: Integer -> String
showC 0 = ""
showC 1 = ""
showC (-1) = "-"
showC n = show n

showT :: (Integer, Power) -> String
showT (0, _) = ""
showT (c, Power 0) = show c
showT (c, Power 1) = showC c ++ "x"
showT (c, p) = showC c ++ "x^" ++ show p
  where
    showC 1 = ""
    showC (-1) = "-"
    showC c = show c

instance Show Polynomial where
    show (Polynomial p) = 
        let validS = concat(map (\(co, po) -> show co ++ show po ++ " + ") p)
        in reverse $ drop 3 $ reverse validS

instance Evaluable Polynomial where
    function (Polynomial p) x = getRounded $ sum [fromInteger c * (fromInteger x ** fromInteger n) | (c, Power n) <- p]

instance Differentiable Polynomial where
    derivative (Polynomial []) = []
    derivative (Polynomial ps) = filter (\t -> case t of
                                                  (Const c) -> c /= 0
                                                  (Pw _ _) -> True) $ map termDerivative ps
      where
        termDerivative (c, Power n) =
          let coeff = c * n
              power = Power (n - 1)
          in Pw coeff power







-- INSTANCES FOR TRIGONOMETRIC

instance Show Trigonometric where
  show (Sin (Polynomial [(1, (Power 1))])) = "sinx"
  show (Cos (Polynomial [(1, (Power 1))])) = "cosx"
  show (Sin (Polynomial [(i, (Power 0))])) = "sin" ++ show i
  show (Cos (Polynomial [(i, (Power 0))])) = "cos" ++ show i
  show (Sin (Polynomial [(i, (Power 1))])) = "sin" ++ show i ++"x"
  show (Cos (Polynomial [(i, (Power 1))])) = "cos" ++ show i ++"x"
  show (Sin p) = "sin(" ++ show p ++ ")"
  show (Cos p) = "cos(" ++ show p ++ ")"

instance Evaluable Trigonometric where
    function (Sin p) x = getRounded $ sin (read (show(function p x)))
    function (Cos p) x = getRounded $ cos (read (show(function p x)))

instance Differentiable Trigonometric where
    derivative (Sin poly) = map (\(Pw c (Power n)) -> Trig c (Power n) (Cos poly)) $ filter (\(Pw c _) -> c /= 0) $ derivative poly
    derivative (Cos poly) = map (\(Pw c (Power n)) -> Trig (-c) (Power n) (Sin poly)) $ filter (\(Pw c _) -> c /= 0) $ derivative poly





-- INSTANCES FOR EXPONENTIAL


instance Show Exponential where
  show (Exponential p) = "e^(" ++ showExp p ++ ")"
    where
      showExp (Polynomial []) = "0"
      showExp (Polynomial [(c, p)]) = showT c p
      showExp (Polynomial ((c, p):xs)) = showT c p ++ " + " ++ showExp (Polynomial xs)

      showT c (Power 0) = showC c
      showT c (Power 1) = showC c ++ "x"
      showT c (Power n) = showC c ++ "x^" ++ show n

      showC c
        | c == 1 = ""
        | c == -1 = "-"
        | otherwise = show c



instance Evaluable Exponential where
    function (Exponential p) x = getRounded $ e ** realToFrac (function p x)
   -- read (show(function p x))
   -- (fromInteger x) ** (fromInteger n)
   -- function (fromInteger(read (show(function p x)))) (fromInteger exp)

instance Differentiable Exponential where
    derivative (Exponential p) = map (\(Pw c' p') -> let temp = Polynomial [(c', p')] in Exp c' p' (Exponential p)) $ filter (\(Pw c' _) -> c' /= 0) $ derivative p



-- INSTANCES FOR TERM
--data Term = Const Integer | Pw Integer Power | Trig Integer Power Trigonometric | Exp Integer Power Exponential
instance Show Term where
    show (Const x) = "x"
    show(Pw _ (Power 0)) =  ""
    show(Pw 0 _) =  "0"
    show(Pw i (Power 1)) =  "x"
    show(Pw 1 (Power n)) =  "x^"++ show n
    show(Pw i (Power n)) =  show i ++"x^"++ show n
    show(Trig i (Power 0) (Sin p)) = show i ++ "sin(" ++ show p ++ ")"
    show(Trig i (Power 1) (Sin p)) = show i ++"x"++"sin(" ++ show p ++ ")"
    show(Trig i (Power n) (Sin p)) = show i ++("x^" ++ show n)++"sin(" ++ show p ++ ")"
    show(Trig i (Power 0) (Cos p)) = show i ++ show (Cos p)
    show(Trig i (Power 1) (Cos p)) = show i ++"x"++ show (Cos p)
    show(Trig i (Power n) (Cos p)) = show i ++("x^" ++ show n)++ show (Cos p)
    
instance Evaluable Term where
    function (Pw i (Power n)) x = getRounded (fromInteger (i * round (function (Power n) x)))

instance Differentiable Term where
    derivative _ = []




-- INSTANCES FOR [TERM]

instance Evaluable [Term] where
    function _ = \x -> 0.0

instance Differentiable [Term] where
    derivative _ = []
