import java.util.ArrayList;

public class CengTreeNodeInternal extends CengTreeNode
{
    private ArrayList<Integer> keys;
    private ArrayList<CengTreeNode> children;
    public CengTreeNodeInternal(CengTreeNode parent)
    {
        super(parent);

        // TODO: Extra initializations, if necessary.
        this.keys = new ArrayList<>();
        this.children = new ArrayList<>();
        this.type = CengNodeType.Internal;
    }

    // GUI Methods - Do not modify
    public ArrayList<CengTreeNode> getAllChildren()
    {
        return this.children;
    }
    public Integer keyCount()
    {
        return this.keys.size();
    }
    public Integer keyAtIndex(Integer index)
    {
        if(index >= this.keyCount() || index < 0)
        {
            return -1;
        }else
        {
            return this.keys.get(index);
        }
    }

    // Extra Functions
    public void addK(Integer key) {
        boolean flag = false;
        int i = 0;
        int ksize = this.keys.size();
        while (i < ksize) {
            if (this.keys.get(i) > key) {
                this.keys.add(i, key);
                flag = true;
                break;
            }
            ksize = this.keys.size();
            i++;
        }


        if (!flag) {
            this.keys.add(key);
        }
    }
    public void addN(Integer key, CengTree tree, CengTreeNode node) {
        boolean flag = false;
        int i = 0;
        int ksize = this.keys.size();
        while (i < ksize) {
            if (this.keys.get(i) > key) {
                this.children.add(i, node);
                flag = true;
                break;
            }
            i++;
        }
        int csize = this.children.size();

        if (!flag) {
            this.children.add(node);
            csize = this.children.size();
        }

        node.setParent(this);

        if (ksize > CengTreeNode.order * 2) {
            CengTreeNodeInternal tmpI = new CengTreeNodeInternal(this.getParent());
            int midKeyIndex = (int) Math.floor((double) ksize / 2);
            int tmp = this.keys.get(midKeyIndex);

            i = midKeyIndex + 1;
            while (i < ksize) {
                tmpI.keys.add(this.keys.get(i));
                i++;
                ksize = this.keys.size();
            }


            if (ksize > midKeyIndex) {
                this.keys.subList(midKeyIndex, ksize).clear();
            }

            i = midKeyIndex + 1;
            while (i < csize) {
                this.children.get(i).setParent(tmpI);
                tmpI.children.add(this.children.get(i));
                i++;
            }csize = this.children.size();


            if (csize > midKeyIndex + 1) {
                this.children.subList(midKeyIndex + 1, csize).clear();
            }

            if (this.getParent() == null) {
                CengTreeNodeInternal tmpR = new CengTreeNodeInternal(null);
                tree.root = tmpR;
                tmpR.addN(this.keys.get(0), tree, this);
                tmpR.addK(tmp);
                tmpR.addN(tmp, tree, tmpI);
            } else {
                CengTreeNodeInternal tmpP = (CengTreeNodeInternal) this.getParent();
                tmpP.addK(tmp);
                tmpP.addN(tmp, tree, tmpI);
            }
        }
    }

    public CengTreeNode search(Integer key) {
        int i = 0;
        int ksize = this.keys.size();
        while (i < ksize) {
            if (this.keys.get(i) > key) {
                return this.children.get(i);
            }i++;
        }
        return this.children.get(this.children.size() - 1);
    }

    @Override
    public void addBook(CengBook book, CengTree tree) {
        boolean flag = false;
        int i = 0;
        int ksize = this.keys.size();
        while (i < ksize) {
            if (this.keys.get(i) > book.getBookID()) {
                this.children.get(i).addBook(book, tree);
                flag = true;
                break;
            }
            i++;
        }
        if (!flag) {
            this.children.get(this.children.size() - 1).addBook(book, tree);
        }
    }

    public void printWC(int space) {
        this.printS(space);
        System.out.println("<index>");
        int ksize = this.keys.size();
        int i = 0;
        while (i < ksize) {
            this.printS(space);
            System.out.println(this.keys.get(i));
            i++;
        }
        this.printS(space);
        System.out.println("</index>");
    }

    @Override
    public void print(int space) {
        this.printWC(space);
        space++;
        int i = 0;
        int csize = this.children.size();
        while (i < csize) {
            this.children.get(i).print(space);
            i++;
        }
    }
}
