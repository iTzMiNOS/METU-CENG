#include "kpop.h"
#include "metal.h"
#include "rock.h"
#include "jazz.h"

int KPopBand::play(MusicBand *other)
{

    double C;
    double energy = get_energy();
    double talent = get_talent();
    double fans = get_fan_count();
    if (dynamic_cast<KPopBand*>(other)) {
        C = 2;
        
        set_energy(energy - energy * 0.2);
        if(energy < 0){
            energy = 0;
            return 0;
        }
        return C * (fans + 0.1 * talent * energy);
    }else if (dynamic_cast<MetalBand*>(other)) {
        C = 0.5;
        
        set_energy(energy - energy * 0.2);
        if(energy < 0){
            energy = 0;
            return 0;
        }
        return C * (fans + 0.1 * talent * energy);
    }else if (dynamic_cast<JazzBand*>(other)) {
        C = 0.5;

        set_energy(energy - energy * 0.2);
        if(energy < 0){
            energy = 0;
            return 0;
        }
        return C * (fans + 0.1 * talent * energy);
    }else if (dynamic_cast<RockBand*>(other)) {
        C = 0.5;

        set_energy(energy - energy * 0.2);
        if(energy < 0){
            energy = 0;
            return 0;
        }
        return C * (fans + 0.1 * talent * energy);
    }
}

void KPopBand::rehearse(void) 
{
    double energy = get_energy();
    double talent = get_talent();
    
    set_talent(get_talent() + 0);
    
    set_energy(energy - 0.5 * 0.2);
    if(energy < 0) energy = 0;
}