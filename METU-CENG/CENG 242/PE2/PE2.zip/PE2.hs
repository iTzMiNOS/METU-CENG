module PE2 where

-- PE2: Dungeon Crawler
-- Dungeon map is :: Tree Chamber [Encounter]
-- Each encounter is either a fight or a treasure
-- Fights deal you damage (reduce HP) but enemies drop some gold (add
-- gold)
-- Tresures just give gold, or potions (which give hp)
-- Nodes hold encounters, when you visit a node you go through all of them in order
-- You start with a certain amount of HP and 0 gold.
-- You lose HP and accumulate gold as you descend the tree and go through encounters

-- Polymorphic tree structure
data Tree a b = EmptyTree | Leaf a b | Node a b [Tree a b] deriving (Show, Eq)

-- Every location in the tree is of some Chamber type.
data Chamber = Cavern |
               NarrowPassage |
               UndergroundRiver |
               SlipperyRocks deriving (Show, Eq)

-- An enemy has a name, an amount of damage that it deals
-- and an amount of gold that it drops (in that order).
data Enemy = Enemy String Integer Integer deriving (Show, Eq)

-- Gold n gives n amount of gold
-- Potion n heals n hp
data Loot = Gold Integer | Potion Integer deriving (Show, Eq)

-- An encounter is either a Fight with an Enemy, or a treasure where
-- you find Loot
data Encounter = Fight Enemy | Treasure Loot deriving (Show, Eq)

-- This is a type synonym for how we will represents our dungeons
type Dungeon = Tree Chamber [Encounter]

--giveLootOrTakeHp :: Encounter -> Integer -> (Integer,Integer)
--giveLootOrTakeHp (act conf) hp =
--    if (act == Fight) then let (Enemy _ damage enemyloot) = conf
 --                              rhp = if (hp - damage) <= 0 then 0 else (hp - damage)
  --                          in (rhp,enemyloot)
   --                   else let (gtype value) = conf
  --                             gval = if (gtype == Gold) then value else 0
   --                            rhp = if (gtype == Gold) then hp else hp + value
   --                         in (rhp,gval)

countEnc :: Integer -> Integer -> [Encounter] -> (Integer, Integer)
countEnc hp gold [] = (hp, gold)
countEnc hp gold enc =
    let encins = head enc
        (hp2, gold2) = case encins of 
                    Fight (Enemy name damage g2) -> (-damage, g2)
                    Treasure (Gold val) -> (0, val)
                    Treasure (Potion val) -> (val, 0)
        fhp = if (hp + hp2) < 0 then 0 else (hp + hp2)
        fgold = gold + gold2
    in countEnc fhp fgold (tail enc)

traversePath2 :: Integer -> Integer -> Dungeon -> [Int] -> (Integer, Integer)
traversePath2 hp gold _ [] = (hp, gold)
traversePath2 hp gold EmptyTree _ = (hp, gold)
traversePath2 0 gold _ _ = (0, gold)
traversePath2 hp gold (Node cham enc child) (x:xs) =
    let lenChildren = length child
        cNode = if x >= lenChildren then EmptyTree else child !! x
        enclist = case cNode of
                    EmptyTree -> []
                    Leaf _ enc -> enc
                    Node _ enc child -> enc
        (hp2, gold2) = countEnc hp gold enclist
    in traversePath2 hp2 (gold2) cNode xs

-- First argument is starting HP
-- Second argument is the dungeon map
-- Third argument is the path (each integer in the list shows what child
-- you descend into)
-- Calculate how much HP you have left and how much gold you've
-- accumulated after traversing the given path
traversePath :: Integer -> Dungeon -> [Int] -> (Integer, Integer)
traversePath hp (Node cham enc child) path =
    traversePath2 hp 0 (Node cham enc child) path

getGold :: Integer -> [Encounter] -> Integer
getGold hp [] = 0
getGold hp enc = 
    let encins = head enc
    in case encins of 
        Fight (Enemy name damage g2) ->
            if (hp - damage) <= 0 then 0
            else g2 + getGold (hp - damage) (tail enc)
        Treasure (Gold val) -> 
            val + getGold hp (tail enc)
        Treasure (Potion val) -> 
            getGold (hp + val) (tail enc)

findMaximumGain2 :: Integer -> Dungeon -> Integer
findMaximumGain2 _ EmptyTree = 0
findMaximumGain2 hp (Leaf _ enc) = getGold hp enc
findMaximumGain2 hp (Node _ enc child) =
  let ghchange = map goldhp enc
      dcalc = sum [damage | Fight (Enemy _ damage _) <- enc]
      nhp = hp - dcalc
      igain = map (findMaximumGain2 nhp) child
      mgain = maximum igain
      fgain = getGold hp enc + mgain
  in fgain
  where
    goldhp (Fight (Enemy _ _ g)) = g
    goldhp _ = 0

-- First argument is starting HP
-- Second argument is dungeon map
-- Find which path down the tree yields the most gold for you
-- You cannot turn back, i.e. you'll find a non-branching path
-- You do not need to reach the bottom of the tree
-- Return how much gold you've accumulated
findMaximumGain :: Integer -> Dungeon -> Integer
findMaximumGain 0 _ = 0
findMaximumGain hp EmptyTree = 0
findMaximumGain hp (Leaf _ enc) = getGold hp enc
findMaximumGain hp (Node _ _ child) = maximum $ map (findMaximumGain2 hp) child


isEmptyTree :: Dungeon -> Bool
isEmptyTree (Leaf _ []) = True
isEmptyTree _ = False

isViable :: Integer -> [Encounter] -> Bool
isViable hp [] = True
isViable hp enc = 
    let encins = head enc
    in case encins of 
        Fight (Enemy name damage g2) ->
            if (hp - damage) <= 0 then False
            else isViable (hp - damage) (tail enc)
        Treasure (Gold val) -> 
            isViable hp (tail enc)
        Treasure (Potion val) -> 
            isViable hp (tail enc)


hpReturn :: Integer -> [Encounter] -> Integer
hpReturn hp [] = hp
hpReturn hp enc = 
    let encins = head enc
    in case encins of 
        Fight (Enemy name damage g2) ->
            hpReturn hp (tail enc) - damage
        Treasure (Gold val) -> 
            hpReturn hp (tail enc)
        Treasure (Potion val) -> 
            hpReturn hp (tail enc) + val

-- First argument is starting HP
-- Second argument is the dungeon map
-- Remove paths that you cannot go thorugh with your starting HP. (By
-- removing nodes from tree).
-- Some internal nodes may become leafs during this process, make the
-- necessary changes in such a case.
findViablePaths :: Integer -> Dungeon -> Dungeon
findViablePaths 0 _ = EmptyTree
findViablePaths _ EmptyTree = EmptyTree
findViablePaths hp (Leaf cham enc) =
  if hpReturn hp enc > 0
  then Leaf cham enc
  else EmptyTree
findViablePaths hp (Node cham enc child) =
  let vChild = map (findViablePaths (hpReturn hp enc)) child
      neChild = filter (/= EmptyTree) vChild
  in case neChild of
      [] -> Leaf cham enc
      _ -> Node cham enc neChild
    
-- First argument is starting HP
-- Second Argument is dungeon map
-- Find, among the viable paths in the tree (so the nodes you cannot
-- visit is already removed) the two most distant nodes, i.e. the two
-- nodes that are furthest awat from each other.
mostDistantPair :: Integer -> Dungeon -> (Integer, Dungeon)
mostDistantPair 0 _ = (0, EmptyTree)
mostDistantPair hp (Node _ _ []) = (0, EmptyTree)
mostDistantPair _ _ = (0, EmptyTree)


-- Find the subtree that has the highest total gold/damage ratio
-- Simply divide the total gold in the subtree by the total damage
-- in the subtree. You only take whole subtrees (i.e you can take a new
-- node as the root of your subtree, but you cannot remove nodes
-- below it). Note that the answer may be the whole tree.
mostEfficientSubtree :: Dungeon -> Dungeon
mostEfficientSubtree _ = EmptyTree
mostEfficientSubtree (Leaf cham enc) = (Leaf cham enc)
