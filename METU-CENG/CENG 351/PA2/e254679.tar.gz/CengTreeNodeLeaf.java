import java.util.ArrayList;

public class CengTreeNodeLeaf extends CengTreeNode
{
    private ArrayList<CengBook> books;
    // TODO: Any extra attributes

    public CengTreeNodeLeaf(CengTreeNode parent)
    {
        super(parent);
        // TODO: Extra initializations
        this.type = CengNodeType.Leaf;
        this.books = new ArrayList<>();
    }

    // GUI Methods - Do not modify
    public int bookCount()
    {
        return books.size();
    }
    public Integer bookKeyAtIndex(Integer index)
    {
        if(index >= this.bookCount()) {
            return -1;
        } else {
            CengBook book = this.books.get(index);

            return book.getBookID();
        }
    }

    // Extra Functions
    public CengBook search(Integer key) {
        int i = 0;
        int bsize = this.books.size();
        while (i < bsize) {
            if (this.books.get(i).getBookID().equals(key)) {
                return this.books.get(i);
            }
            i++;
        }


        return null;
    }
    @Override
    public void addBook(CengBook book, CengTree tree) {
        boolean inserted = false;
        int i = 0;
        int bsize = this.books.size();
        while (i < bsize) {
            CengBook temp = this.books.get(i);
            if (temp.getBookID() > book.getBookID()) {
                this.books.add(i, book);
                inserted = true;
                break;
            }
            i++;
        }
        bsize = this.books.size();
        if (!inserted) {
            this.books.add(book);
        }
        bsize = this.books.size();
        if (bsize > CengTreeNodeLeaf.order * 2) {
            int midIndex = (int) Math.floor((double) bsize / 2);
            CengBook midInd = this.books.get(midIndex);
            CengTreeNodeLeaf tmpL = new CengTreeNodeLeaf(this.getParent());
            i = midIndex;
            while (i < bsize) {
                tmpL.books.add(this.books.get(i));
                i++;
            }
            bsize = this.books.size();
            if (bsize > midIndex) {
                this.books.subList(midIndex, bsize).clear();
            }
            if (this.getParent() == null) {
                CengTreeNodeInternal tmpR = new CengTreeNodeInternal(null);

                tree.root = tmpR;

                tmpR.addN(this.books.get(0).getBookID(), tree, this);
                tmpR.addK(midInd.getBookID());
                tmpR.addN(midInd.getBookID(), tree, tmpL);
            } else {
                CengTreeNodeInternal tmpP = (CengTreeNodeInternal) this.getParent();

                tmpP.addK(midInd.getBookID());
                tmpP.addN(midInd.getBookID(), tree, tmpL);
            }
        }
    }

    @Override
    public void print(int space) {
        this.printS(space);
        System.out.println("<data>");

        int i = 0;
        int bsize = this.books.size();
        while (i < bsize) {
            this.printBook(this.books.get(i), space);
            i++;
        }

        this.printS(space);
        System.out.println("</data>");
    }
}
